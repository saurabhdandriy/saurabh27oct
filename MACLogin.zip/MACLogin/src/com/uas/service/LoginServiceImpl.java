package com.uas.service;

import org.springframework.stereotype.Service;



@Service
public class LoginServiceImpl implements ILoginService
{

		
		
		@Override
		public boolean validateLoginDetails(String usr, String pass) 
		{
			if(usr.equals("admin") && pass.equals("admin"))
			{
				return true;
			}
			else
			{
				 return false;
			}
		}

		

	}

	


