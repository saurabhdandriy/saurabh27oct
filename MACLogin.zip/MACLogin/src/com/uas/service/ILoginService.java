package com.uas.service;


public interface ILoginService {

	public boolean validateLoginDetails(String usr, String pass);

	
	
}
