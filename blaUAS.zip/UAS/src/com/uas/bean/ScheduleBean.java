package com.uas.bean;





import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.NamedQuery;
import org.springframework.format.annotation.DateTimeFormat;


@Entity
	@NamedQuery(name="getAllSchedule",query="select sb from ScheduleBean sb")
@Table(name="Programs_Scheduled")
public class ScheduleBean {
	
	@Id
	@GeneratedValue
	@Column(name="Schedule_Program_Id ")
	private int scheduleProgramId;
	@OneToOne
	@JoinColumn(name="Program_Name")
	private ProgramBean programName;
	@Column(name="Location ")
	private String location;
	
	
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@Column(name="StartDate ")
	private Date startDate;
	
	
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@Column(name="EndDate ")
	private Date endDate;
	@Column(name="Sessions_Per_Week number")
	private int  SessionsPerWeek;
	
	public int getSessionsPerWeek() {
		return SessionsPerWeek;
	}
	public void setSessionsPerWeek(int sessionsPerWeek) {
		this.SessionsPerWeek = sessionsPerWeek;
	}
	public ScheduleBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ScheduleBean(int scheduleProgramId, ProgramBean programName,
			String location, Date startDate, Date endDate,
			int sessionsPerWeek) {
		super();
		this.scheduleProgramId = scheduleProgramId;
		this.programName = programName;
		this.location = location;
		this.startDate = startDate;
		this.endDate = endDate;
		this.SessionsPerWeek = sessionsPerWeek;
	}
	public int getScheduleProgramId() {
		return scheduleProgramId;
	}
	public void setScheduleProgramId(int scheduleProgramId) {
		this.scheduleProgramId = scheduleProgramId;
	}
	public ProgramBean getProgramName() {
		return programName;
	}
	public void setProgramName(ProgramBean programName) {
		this.programName = programName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
	@Override
	public String toString() {
		return "ScheduleProgramId  =  " + scheduleProgramId
				+ ", ProgramName  =  " + programName + ", Location  =  " + location
				+ ", StartDate  =  " + startDate + ", EndDate  =  " + endDate
				+ ", SessionsPerWeek  =  " + SessionsPerWeek;
	}
	
}
