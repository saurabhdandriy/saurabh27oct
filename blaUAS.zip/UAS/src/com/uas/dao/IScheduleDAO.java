package com.uas.dao;

import java.util.ArrayList;

import com.uas.bean.ScheduleBean;

public interface IScheduleDAO {

	int addScheduleDetails(ScheduleBean sb);

	ArrayList<ScheduleBean> viewAllScheduleDetails();

	int deleteScheduleDetails(int deleteScheduleId);

	ScheduleBean updateScheduleDetails(int scheId);

	int updateNewScheduleDetails(ScheduleBean usbo);
	
	
}
