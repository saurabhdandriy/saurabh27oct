package com.uas.dao;

import java.util.ArrayList;

import javax.jms.Session;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
import com.uas.bean.ScheduleBean;

@Repository
@Transactional
public class ScheduleDAOImplementation implements IScheduleDAO {
	static int count=0;
	

	@PersistenceContext 
	private EntityManager entitymanager;
	
	
	@Override
	public int addScheduleDetails(ScheduleBean sb) {
		entitymanager.persist(sb);
		return sb.getScheduleProgramId();
	}
	
	@Override
	public ArrayList<ScheduleBean> viewAllScheduleDetails() {
		Query viewQuery=entitymanager.createNamedQuery("getAllSchedule");	
		
		return (ArrayList<ScheduleBean>) viewQuery.getResultList();
	}

	@Override
	public int deleteScheduleDetails(int deleteScheduleId) {
		
		

		Query deleteQuery=entitymanager.createQuery("delete ScheduleBean where scheduleProgramId =:delscheid");
		deleteQuery.setParameter("delscheid",deleteScheduleId);
		int result = deleteQuery.executeUpdate();
		return result;
	}
	


	@Override
	public ScheduleBean updateScheduleDetails(int scheId) {
		
		Query updateQuery=entitymanager.createQuery("select sb from ScheduleBean sb where scheduleProgramId =:upscheid");
		updateQuery.setParameter("upscheid", scheId);
		ScheduleBean ubs = (ScheduleBean) updateQuery.getSingleResult();
	
		return ubs;
	}
	
/*	Query query = session.createQuery("update Stock set stockName = :stockName" +
    				" where stockCode = :stockCode");
query.setParameter("stockName", "DIALOG1");
query.setParameter("stockCode", "7277");
int result = query.executeUpdate();

	private int scheduleProgramId;
	private String programName;
	private String location;
	private String startDate;
	private String endDate;
	private int  SessionsPerWeek;
*/
/*	Session s = DB.getSession();
	Transaction tr = s.beginTransaction();
	Criteria cr = s.createCriteria(Connection.Pojo.Message.class);
	cr.add(Restrictions.eq("toUser", 3));
	List<Connection.Pojo.Message> l = cr.list();
	for (Connection.Pojo.Message msg : l) {
	    msg.setStatus((byte) 0);
	    s.update(msg);
	}
	tr.commit();
	s.close();*/

	/*@Override
	public int updateNewScheduleDetails(ScheduleBean usbo, int scheduleId) {
		;
		Query updateNameQuery=entitymanager.createQuery("update ScheduleBean set programName =:progName"+
	"where scheduleProgramId =:scheid ");
		updateNameQuery.setParameter("progName", usbo.getProgramName());
		updateNameQuery.setParameter("scheid",scheduleId);
		count = updateNameQuery.executeUpdate();
		
		
		Query updateLocationQuery=entitymanager.createQuery("update ScheduleBean set location =:loc"+
		"where scheduleProgramId =:scheid");
		updateLocationQuery.setParameter("loc", usbo.getLocation());
		updateLocationQuery.setParameter("scheid", scheduleId);
		count = count +updateLocationQuery.executeUpdate();
		
		Query updateSDateQuery=entitymanager.createQuery("update ScheduleBean set startDate =:sdate"+
		"where scheduleProgramId =:scheid");
		updateSDateQuery.setParameter("sDate", usbo.getStartDate());
		updateLocationQuery.setParameter("scheid", scheduleId);
		count = count + updateLocationQuery.executeUpdate();
		

		Query updateEDateQuery=entitymanager.createQuery("update ScheduleBean set endDate =:edate"+
		"where scheduleProgramId =:scheid");
		updateEDateQuery.setParameter("eDate", usbo.getStartDate());
		updateEDateQuery.setParameter("scheid", scheduleId);
		count = count+updateEDateQuery.executeUpdate();
		
		Query updateSessionQuery=entitymanager.createQuery("update ScheduleBean set session =:sess"+
		"where scheduleProgramId =:scheid");
		updateEDateQuery.setParameter("sess", usbo.getStartDate());
		updateEDateQuery.setParameter("scheid", scheduleId);
		count = count+ updateEDateQuery.executeUpdate();
		
		
		
		return count;
	}
*/
	@Override
	public int updateNewScheduleDetails(ScheduleBean usbo) {
		entitymanager.merge(usbo);
		return usbo.getScheduleProgramId();
	}

}
